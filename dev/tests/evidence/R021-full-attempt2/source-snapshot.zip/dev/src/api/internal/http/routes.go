package controlhttp

import (
	_ "embed"
	"encoding/json"
	"net/http"
	"p11.local/compute/shared/ids"
	"strings"
)

//go:embed routes.json
var routeDocument []byte

type registeredRoute struct {
	OperationID string `json:"operation_id"`
	Method      string `json:"method"`
	Path        string `json:"path"`
	Handler     string `json:"handler"`
	Anonymous   bool   `json:"anonymous"`
}

func (s *Server) loadRoutes() bool {
	var manifest struct {
		Version    string            `json:"version"`
		BasePath   string            `json:"base_path"`
		Scope      string            `json:"scope"`
		Operations []registeredRoute `json:"operations"`
	}
	if json.Unmarshal(routeDocument, &manifest) != nil || manifest.Version != "P11_CONTROL_HTTP_R019" || manifest.BasePath != prefix || len(manifest.Operations) == 0 {
		return false
	}
	pairs, operations := map[string]bool{}, map[string]bool{}
	for _, r := range manifest.Operations {
		key := r.Method + " " + r.Path
		if !ids.Valid(r.OperationID) || pairs[key] || operations[r.OperationID] || s.handlerNamed(r.Handler) == nil || !strings.HasPrefix(r.Path, "/") ||
			(r.Method != "GET" && r.Method != "POST" && r.Method != "DELETE" && r.Method != "PATCH") {
			return false
		}
		pairs[key], operations[r.OperationID] = true, true
	}
	s.routes = manifest.Operations
	return true
}
func (s *Server) handlerNamed(name string) handler {
	switch name {
	case "getExecutionManifest":
		return s.getExecutionManifest
	case "getExecutionInput":
		return s.getExecutionInput
	case "claimLease":
		return s.claimLease
	case "routeContracts":
		return s.routeContracts
	case "getRouteContract":
		return s.getRouteContract
	case "createPairing":
		return s.createPairing
	case "enrollDevice":
		return s.enrollDevice
	case "getDevice":
		return s.getDevice
	case "ownDevices":
		return s.ownDevices
	case "heartbeat":
		return s.heartbeat
	case "deviceState":
		return s.deviceState
	case "devicePolicy":
		return s.devicePolicy
	case "sellerProfile":
		return s.sellerProfile
	case "sellerApplication":
		return s.sellerApplication
	case "sellerExit":
		return s.sellerExit
	case "recordConsent":
		return s.recordConsent
	case "ownListings":
		return s.ownListings
	case "ownListing":
		return s.ownListing
	case "listingState":
		return s.listingState
	case "challenge":
		return s.challenge
	case "login":
		return s.login
	case "currentSession":
		return s.currentSession
	case "me":
		return s.me
	case "keys":
		return s.keys
	case "revokeKey":
		return s.revokeKey
	case "services":
		return s.services
	case "quote":
		return s.quote
	case "getQuote":
		return s.getQuote
	case "order":
		return s.order
	case "getOrder":
		return s.getOrder
	}
	return nil
}
func pathMatches(pattern, path string) bool {
	a, b := strings.Split(pattern, "/"), strings.Split(path, "/")
	if len(a) != len(b) {
		return false
	}
	for i, segment := range a {
		if strings.HasPrefix(segment, "{") && strings.HasSuffix(segment, "}") {
			if !ids.Valid(b[i]) {
				return false
			}
		} else if segment != b[i] {
			return false
		}
	}
	return true
}
func (s *Server) route(r *http.Request) (handler, string, bool) {
	var selected *registeredRoute
	methods := []string{}
	for i := range s.routes {
		entry := &s.routes[i]
		if !pathMatches(prefix+entry.Path, r.URL.Path) {
			continue
		}
		methods = append(methods, entry.Method)
		if selected == nil || entry.Method == r.Method {
			selected = entry
		}
	}
	if selected == nil {
		return nil, "", false
	}
	return s.handlerNamed(selected.Handler), strings.Join(methods, ","), selected.Anonymous
}
